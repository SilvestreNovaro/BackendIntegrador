package com.example.integrador.exceptions;

public class PacienteNotFound extends Exception {
}
