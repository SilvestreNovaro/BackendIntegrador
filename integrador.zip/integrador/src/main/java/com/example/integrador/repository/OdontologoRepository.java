package com.example.integrador.repository;

import com.example.integrador.model.Odontologo;
import com.example.integrador.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface OdontologoRepository extends JpaRepository<Odontologo, Integer> {



    @Query("SELECT 0 FROM ODONTOLOGO")
    List<Odontologo> listar();

    @Modifying
    @Transactional
    @Query("UPDATE ODONTOLOGO O SET O.NOMBRE = ?1 WHERE O.ID = ?1")
    Odontologo actualizar(int id, String nombre);

}
