package com.example.integrador.exceptions;

public class OdontologoNotFound extends Exception{
}
